Use Start.ipynb to interact, manage, run and test the Neural Network. 

`neuralnetwork.py` is the main file and class for all logic. Other `.py` files are smaller components used to run the MLP algorithm.


Project for course "Mathematics for Machine Learning (MA4029)", 7.5 HP

Created by: Dennis Mitzeus - 70002183, Halmstad University

Written: 2024-05-13
Updated: 2024-05-13
 
